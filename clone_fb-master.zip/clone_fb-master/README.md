# clone_fb
Clone fb frind  new mithod      استخراج فرند های فیسبوک روش جدید
*#TermuxCommands


Telegram   http://T.ME/SULTANI1122


1.  pkg install python2-dev python2 git -y 
2.  apt install python2 
3.  apt install git 
4.  pip2 install mechanize 
5.  pip2 install requests 
6.  git clone https://github.com/Mohammadjan1122/clone_fb 
7.  cd clone_fb 
8.  python2 xpt_fb_clon.py
USERNAME: mohammad
</s>avkanîo
رمز عبور: هکرh
